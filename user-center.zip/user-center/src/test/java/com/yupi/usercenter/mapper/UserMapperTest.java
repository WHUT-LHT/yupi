package com.yupi.usercenter.mapper;

import static org.junit.Assert.*;

public class UserMapperTest {

}